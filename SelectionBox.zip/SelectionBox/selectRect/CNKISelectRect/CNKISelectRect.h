//
//  CNKISelectRect.h
//  selectRect
//
//  Created by joke on 2021/7/26.
//

#import <Foundation/Foundation.h>

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface CNKISelectRect : NSObject

+ (CNKISelectRect *)defaultRect;

//
- (void)showWithRect:(NSRect)rect toView:(NSView *)view;

- (void)changingBlock:(void(^)(NSRect rect))changingBlock;

- (void)changedBlock:(void(^)(NSRect rect))changedBlock;

- (void)remove;

//
- (void)mouseDown:(NSPoint)point;

- (void)mouseMove:(NSPoint)point;

- (void)mouseUp:(NSPoint)point;

@end

NS_ASSUME_NONNULL_END
