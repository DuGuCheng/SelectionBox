//
//  CNKIRectNodeLayer.h
//  selectRect
//
//  Created by joke on 2021/7/26.
//

#import <QuartzCore/QuartzCore.h>

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

//坐标系原点默认在左上角;若原点在左下角，position名称与实际位置上下颠倒，但不影响正常运行。
typedef NS_ENUM(NSInteger,CNKIRectNodePosition) {
    CNKIRectNodePosition_Left_Above = 0,
    CNKIRectNodePosition_Left_Middle,
    CNKIRectNodePosition_Left_Below,
    CNKIRectNodePosition_Middle_Above,
    CNKIRectNodePosition_Middle_Below,
    CNKIRectNodePosition_Right_Middle,
    CNKIRectNodePosition_Right_Below,
    CNKIRectNodePosition_Right_Above,
};

@interface CNKIRectNodeLayer : CAShapeLayer

@property (nonatomic,assign) CNKIRectNodePosition nodePosition;

- (void)addNodeToView:(NSView *)view;

- (void)setNodeFrame:(NSRect)frame;

- (NSRect)mouseOffsetPoint:(NSPoint)offsetPoint;

@end

NS_ASSUME_NONNULL_END
