//
//  CNKIRectBorderLayer.h
//  selectRect
//
//  Created by joke on 2021/7/26.
//

#import <QuartzCore/QuartzCore.h>

#import <Cocoa/Cocoa.h>

NS_ASSUME_NONNULL_BEGIN

@interface CNKIRectBorderLayer : CAShapeLayer

- (void)addBorderToView:(NSView *)view;

- (void)setBorderFrame:(NSRect)frame;

@end

NS_ASSUME_NONNULL_END
