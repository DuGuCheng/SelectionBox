//
//  CNKIRectBorderLayer.m
//  selectRect
//
//  Created by joke on 2021/7/26.
//

#import "CNKIRectBorderLayer.h"

@interface CNKIRectBorderLayer ()

@property (nonatomic,weak) NSView *backView;

@end

@implementation CNKIRectBorderLayer

- (void)addBorderToView:(NSView *)view{
    
    self.backView = view;
    
    self.borderColor = [NSColor colorWithRed:80/255. green:102/255. blue:151/255. alpha:1].CGColor;
    
    self.borderWidth = 2;
    
    view.wantsLayer = YES;
    
    [view.layer addSublayer:self];
}

- (void)setBorderFrame:(NSRect)frame{
    
    [self setFrame:CGRectMake(frame.origin.x, frame.origin.y, frame.size.width, frame.size.height)];
}

@end
