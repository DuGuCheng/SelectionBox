//
//  CNKIRectNodeLayer.m
//  selectRect
//
//  Created by joke on 2021/7/26.
//

#import "CNKIRectNodeLayer.h"

@interface CNKIRectNodeLayer ()

@property (nonatomic,weak) NSView *backView;

@property (nonatomic,assign) NSRect currentBorderFrame;

@end

@implementation CNKIRectNodeLayer

- (void)addNodeToView:(NSView *)view{
    
    self.backView = view;
        
    self.backgroundColor = [NSColor colorWithRed:80/255. green:102/255. blue:151/255. alpha:1].CGColor;
    
    view.wantsLayer = YES;
    
    [view.layer addSublayer:self];
}

- (void)setNodeFrame:(NSRect)frame{
    
    self.currentBorderFrame = frame;
    
    NSRect rect = [self getNodeRectByBorderRect:frame];
    
    self.frame = rect;
}

- (NSRect)getNodeRectByBorderRect:(NSRect)borderRect{
    
    CGFloat x = borderRect.origin.x;
    CGFloat y = borderRect.origin.y;
    CGFloat width = borderRect.size.width;
    CGFloat height = borderRect.size.height;
    
    switch (self.nodePosition) {
        case CNKIRectNodePosition_Left_Above:
            return NSMakeRect(x, y, 10, 10);
            break;
        case CNKIRectNodePosition_Left_Middle:
            return NSMakeRect(x, y + height/2. - 5, 10, 10);
            break;
        case CNKIRectNodePosition_Left_Below:
            return NSMakeRect(x, y + height - 10, 10, 10);
            break;
        case CNKIRectNodePosition_Middle_Above:
            return NSMakeRect(x + width/2. - 5, y, 10, 10);
            break;
        case CNKIRectNodePosition_Middle_Below:
            return NSMakeRect(x + width/2. - 5, y + height - 10, 10, 10);
            break;
        case CNKIRectNodePosition_Right_Above:
            return NSMakeRect(x + width - 10, y, 10, 10);
            break;
        case CNKIRectNodePosition_Right_Middle:
            return NSMakeRect(x + width - 10, y + height/2. - 5, 10, 10);
            break;
        case CNKIRectNodePosition_Right_Below:
            return NSMakeRect(x + width - 10, y + height - 10, 10, 10);
            break;
            
        default:
            break;
    }
    
    return NSMakeRect(x, y, 10, 10);
}

- (NSRect)mouseOffsetPoint:(NSPoint)offsetPoint{
         
    CGFloat x = self.currentBorderFrame.origin.x;
    CGFloat y = self.currentBorderFrame.origin.y;
    CGFloat width = self.currentBorderFrame.size.width;
    CGFloat height = self.currentBorderFrame.size.height;
            
    switch (self.nodePosition) {
        case CNKIRectNodePosition_Left_Above:
            return NSMakeRect(x + offsetPoint.x, y + offsetPoint.y, width - offsetPoint.x, height - offsetPoint.y);
            break;
        case CNKIRectNodePosition_Left_Middle:
            return NSMakeRect(x + offsetPoint.x, y, width - offsetPoint.x, height);
            break;
        case CNKIRectNodePosition_Left_Below:
            return NSMakeRect(x + offsetPoint.x, y, width - offsetPoint.x, height + offsetPoint.y);
            break;
        case CNKIRectNodePosition_Middle_Above:
            return NSMakeRect(x, y + offsetPoint.y, width, height - offsetPoint.y);
            break;
        case CNKIRectNodePosition_Middle_Below:
            return NSMakeRect(x, y, width, height + offsetPoint.y);
            break;
        case CNKIRectNodePosition_Right_Above:
            return NSMakeRect(x, y + offsetPoint.y, width + offsetPoint.x, height - offsetPoint.y);
            break;
        case CNKIRectNodePosition_Right_Middle:
            return NSMakeRect(x, y, width + offsetPoint.x, height);
            break;
        case CNKIRectNodePosition_Right_Below:
            return NSMakeRect(x, y, width + offsetPoint.x, height + offsetPoint.y);
            break;
            
        default:
            break;
    }
   
    return NSZeroRect;
}

@end
