//
//  CNKISelectRect.m
//  selectRect
//
//  Created by joke on 2021/7/26.
//

#import "CNKISelectRect.h"

#import "CNKIRectBorderLayer.h"

#import "CNKIRectNodeLayer.h"

@interface CNKISelectRect ()

@property (nonatomic,weak) NSView *backView;

@property (nonatomic,strong) CNKIRectBorderLayer *borderLayer;

@property (nonatomic,strong) NSMutableArray *nodeLayerArray;

@property (nonatomic,weak) CNKIRectNodeLayer *currentNodeLayer;

@property (nonatomic,strong) void (^changedBlock)(NSRect rect);

@property (nonatomic,strong) void (^changingBlock)(NSRect rect);

@property (nonatomic,assign) NSPoint currentPoint;

@property (nonatomic,assign) BOOL isMouseInside;

@property (nonatomic,assign) BOOL isChanged;

@end

@implementation CNKISelectRect

- (NSMutableArray *)nodeLayerArray{
    
    if (_nodeLayerArray == nil) {
        
        _nodeLayerArray = [NSMutableArray array];
        
        for (NSInteger i = 0; i < 8; i ++) {
            
            CNKIRectNodeLayer *nodeLayer = [[CNKIRectNodeLayer alloc] init];
            
            nodeLayer.nodePosition = (CNKIRectNodePosition)i;
            
            [_nodeLayerArray addObject:nodeLayer];
        }
        [_nodeLayerArray exchangeObjectAtIndex:0 withObjectAtIndex:7];
    }
    
    return _nodeLayerArray;
}

- (CNKIRectBorderLayer *)borderLayer{
    
    if (_borderLayer == nil) {
        
        _borderLayer = [[CNKIRectBorderLayer alloc] init];
    }
    
    return _borderLayer;
}

+ (CNKISelectRect *)defaultRect{
    static CNKISelectRect *selectRect = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        selectRect = [[CNKISelectRect alloc] init];
    });
    return selectRect;
}

- (void)showWithRect:(NSRect)rect toView:(NSView *)view{
    
    [self setLayerRect:rect];
    
    self.backView = view;
    
    [self.borderLayer addBorderToView:self.backView];
    
    for (CNKIRectNodeLayer *nodeLayer in self.nodeLayerArray) {
        
        [nodeLayer addNodeToView:self.backView];
    }
}

- (void)setLayerRect:(NSRect)rect{
 
    [CATransaction begin];

    [CATransaction setDisableActions:YES];
  
    [self.borderLayer setBorderFrame:rect];
    
    for (CNKIRectNodeLayer *nodeLayer in self.nodeLayerArray) {
                
        [nodeLayer setNodeFrame:rect];
    }
    
    [CATransaction commit];
}

- (void)changedBlock:(void(^)(NSRect rect))changedBlock{
    
    self.changedBlock = changedBlock;
}

- (void)changingBlock:(void (^)(NSRect))changingBlock{
    
    self.changingBlock = changingBlock;
}

- (void)remove{
    
    [self.borderLayer removeFromSuperlayer];
    
    for (CNKIRectNodeLayer *subNoteLayer in self.nodeLayerArray) {
        
        [subNoteLayer removeFromSuperlayer];
    }
    
    self.backView = nil;
}

//
- (void)mouseDown:(NSPoint)point{
    
    self.currentNodeLayer = nil;
    
    self.isMouseInside = NO;
    
    self.isChanged = NO;
    
    for (CNKIRectNodeLayer *subNodeLayer in self.nodeLayerArray) {
        
        if (NSPointInRect(point, subNodeLayer.frame) && subNodeLayer.hidden == NO) {
            
            self.currentNodeLayer = subNodeLayer;
            
            self.currentPoint = point;
        }
    }
    
    if (self.currentNodeLayer == nil) {
        
        if (NSPointInRect(point, self.borderLayer.frame)) {
            
            self.isMouseInside = YES;
            
            self.currentPoint = point;
        }
    }
}

- (void)mouseMove:(NSPoint)point{
    
    NSRect currentRect = NSZeroRect;
    
    NSPoint offsetPoint = NSMakePoint(point.x - self.currentPoint.x, point.y - self.currentPoint.y);
    
    self.currentPoint = point;
    
    if (self.currentNodeLayer) {
        
        if (offsetPoint.x + self.borderLayer.frame.origin.x < 0) {
            if (self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Left_Above ||
                self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Left_Middle ||
                self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Left_Below) {
                offsetPoint = NSMakePoint( -self.borderLayer.frame.origin.x, offsetPoint.y);
            }
        }
        
        if (offsetPoint.y + self.borderLayer.frame.origin.y < 0) {
            if (self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Left_Above ||
                self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Middle_Above || self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Right_Above) {
                offsetPoint = NSMakePoint( offsetPoint.x, -self.borderLayer.frame.origin.y);
            }
        }
        
        if (offsetPoint.x + self.borderLayer.frame.origin.x + self.borderLayer.frame.size.width > self.backView.frame.size.width) {
            if (self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Right_Above ||
                self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Right_Middle ||
                self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Right_Below) {
                offsetPoint = NSMakePoint( self.backView.frame.size.width - self.borderLayer.frame.size.width - self.borderLayer.frame.origin.x, offsetPoint.y);
            }
            if (self.borderLayer.frame.size.width - offsetPoint.x < 10) {
                
                offsetPoint = NSMakePoint(self.borderLayer.frame.size.width - 10, offsetPoint.y);
            }
        }
        
        if (offsetPoint.y + self.borderLayer.frame.origin.y + self.borderLayer.frame.size.height > self.backView.frame.size.height) {
            if (self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Right_Below ||
                self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Middle_Below ||
                self.currentNodeLayer.nodePosition == CNKIRectNodePosition_Left_Below) {
                offsetPoint = NSMakePoint( offsetPoint.x, self.backView.frame.size.height - self.borderLayer.frame.origin.y - self.borderLayer.frame.size.height);
            }
            if (self.borderLayer.frame.size.height - offsetPoint.y < 10) {
                
                offsetPoint = NSMakePoint(offsetPoint.x, self.borderLayer.frame.size.height - 10);
            }
        }
        
        currentRect = [self.currentNodeLayer mouseOffsetPoint:offsetPoint];
        
        if (currentRect.size.width < 10) {
            
            currentRect = NSMakeRect(currentRect.origin.x, currentRect.origin.y, 10, currentRect.size.height);
        }
        if (currentRect.size.height < 10) {
            
            currentRect = NSMakeRect(currentRect.origin.x, currentRect.origin.y, currentRect.size.width, 10);
        }
    }
    
    if (self.isMouseInside == YES) {
        
        NSRect borderRect = self.borderLayer.frame;
        
        currentRect = NSMakeRect(borderRect.origin.x + offsetPoint.x, borderRect.origin.y + offsetPoint.y, borderRect.size.width, borderRect.size.height);
        
        if (currentRect.origin.x < 0 ) {
            
            currentRect = NSMakeRect(0, currentRect.origin.y, currentRect.size.width, currentRect.size.height);
        }
        
        if (currentRect.origin.y < 0 ) {
            
            currentRect = NSMakeRect(currentRect.origin.x, 0, currentRect.size.width, currentRect.size.height);
        }
        
        if (currentRect.origin.x + currentRect.size.width > self.backView.frame.size.width) {
            
            currentRect = NSMakeRect(self.backView.frame.size.width - currentRect.size.width, currentRect.origin.y, currentRect.size.width, currentRect.size.height);
        }
        if (currentRect.origin.y + currentRect.size.height > self.backView.frame.size.height) {
            
            currentRect = NSMakeRect(currentRect.origin.x, self.backView.frame.size.height - currentRect.size.height, currentRect.size.width, currentRect.size.height);
        }
    }
    
    if (!NSEqualRects(currentRect, NSZeroRect)) {
  
        [self setLayerRect:currentRect];
        
        if (self.changingBlock) {
            
            self.changingBlock(currentRect);
        }
     
        self.isChanged = YES;
    }
}

- (void)mouseUp:(NSPoint)point{
    
    if (self.isChanged == YES) {
        
        if(self.changedBlock){
            
            self.changedBlock(self.borderLayer.frame);
        }
    }
    
    self.currentNodeLayer = nil;
    
    self.isMouseInside = NO;
}

@end
