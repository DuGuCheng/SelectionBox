//
//  ViewController.m
//  selectRect
//
//  Created by joke on 2021/7/26.
//

#import "ViewController.h"

#import "CNKISelectRect.h"

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    [[CNKISelectRect defaultRect] showWithRect:NSMakeRect(100, 100, 200, 200) toView:self.view];
    
    [[CNKISelectRect defaultRect] changedBlock:^(NSRect rect) {
        
        NSLog(@"%@",@(rect));
    }];
}

- (void)mouseDown:(NSEvent *)event{
    
    NSPoint location = [event locationInWindow];
    
    NSPoint point = [self.view convertPoint:location fromView:self.view.window.contentView];
    
    [[CNKISelectRect defaultRect] mouseDown:point];
}

- (void)mouseDragged:(NSEvent *)event{
  
    NSPoint location = [event locationInWindow];
    
    NSPoint point = [self.view convertPoint:location fromView:self.view.window.contentView];
    
    [[CNKISelectRect defaultRect] mouseMove:point];
}
- (void)mouseUp:(NSEvent *)event{
    
    NSPoint location = [event locationInWindow];
    
    NSPoint point = [self.view convertPoint:location fromView:self.view.window.contentView];
    
    [[CNKISelectRect defaultRect] mouseUp:point];
}

- (void)setRepresentedObject:(id)representedObject {
    [super setRepresentedObject:representedObject];

    // Update the view, if already loaded.
}


@end
