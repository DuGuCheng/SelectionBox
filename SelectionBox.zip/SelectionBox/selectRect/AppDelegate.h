//
//  AppDelegate.h
//  selectRect
//
//  Created by joke on 2021/7/26.
//

#import <Cocoa/Cocoa.h>

@interface AppDelegate : NSObject <NSApplicationDelegate>


@end

